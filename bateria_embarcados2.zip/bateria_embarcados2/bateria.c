#include "bateria.h"
#include "kick.h"
#include "clap.h"
#include "crash.h"

enum RhythmComponents {
    KICK_BIT  = 0x01,
    CLAP_BIT  = 0x02,
    CRASH_BIT = 0x04,
};

// struct que define a bateria
struct bateria
{
    uint32_t        sampling_rate;
    uint32_t        time_counter;
    uint8_t         is_paused;
    uint8_t         current_bpm;
    uint8_t         beats_per_measure;
    int8_t          current_beat_index;
    const uint8_t   *rhythm_pattern;
    uint32_t        pattern_length;
    uint32_t        sound_position;       // Posição atual do som
    const int16_t   *active_sound_data;   // Som ativo atual
    uint32_t        sound_length;         // Comprimento do som
};

static baterista n1_baterista;
baterista *bateria_instance(void)
{
    return &n1_baterista;
}

// ritmos
const uint8_t rhythm1[] = {
    KICK_BIT|CRASH_BIT, 0, CLAP_BIT, CRASH_BIT,
    KICK_BIT, KICK_BIT, CLAP_BIT, 0,
    KICK_BIT, KICK_BIT, CLAP_BIT, 0,
    KICK_BIT|CRASH_BIT, 0, CLAP_BIT, CRASH_BIT
};
const uint8_t rhythm2[] = {
    KICK_BIT|CRASH_BIT, 0, KICK_BIT, 0,
    KICK_BIT|CLAP_BIT, KICK_BIT, CLAP_BIT, 0,
    KICK_BIT|CRASH_BIT, 0, KICK_BIT, 0,
    KICK_BIT|CLAP_BIT, KICK_BIT, CLAP_BIT, CRASH_BIT
};
const uint8_t rhythm3[] = {
    KICK_BIT|CRASH_BIT, CLAP_BIT, 0, CLAP_BIT,
    KICK_BIT, 0, KICK_BIT, CLAP_BIT,
    KICK_BIT|CRASH_BIT, CLAP_BIT, 0, CLAP_BIT,
    KICK_BIT, 0, KICK_BIT, CLAP_BIT
};

// struct dos ritmos
typedef struct {
    const char      *name;
    const uint8_t   *pattern;
    uint32_t        length;
} RhythmDescriptor_t;

const RhythmDescriptor_t available_rhythms[] = {
    {"rhythm1", rhythm1, sizeof(rhythm1)},
    {"rhythm2", rhythm2, sizeof(rhythm2)},
    {"rhythm3", rhythm3, sizeof(rhythm3)},
};

//inicializa
void bateria_on(baterista *joh_bonham, bateria_config config)
{
    if (!joh_bonham) return;
    joh_bonham->sampling_rate = config.sample_rate;
    joh_bonham->current_bpm = config.bpm;
    joh_bonham->beats_per_measure = config.beats_per_bar;
    joh_bonham->time_counter = 0;
    joh_bonham->is_paused = 0;
    joh_bonham->current_beat_index = -1;
    joh_bonham->active_sound_data = 0;
    joh_bonham->sound_position = 0;
    joh_bonham->sound_length = 0;
    joh_bonham->rhythm_pattern = available_rhythms[0].pattern;
    joh_bonham->pattern_length = available_rhythms[0].length;
}

//próximo ritmo
const char *get_next_rhythm(baterista *joh_bonham)
{
    if (!joh_bonham) return 0;
    static int rhythm_index = 0;
    rhythm_index = (rhythm_index + 1) % (sizeof(available_rhythms) / sizeof(available_rhythms[0]));
    joh_bonham->rhythm_pattern = available_rhythms[rhythm_index].pattern;
    joh_bonham->pattern_length = available_rhythms[rhythm_index].length;
    joh_bonham->time_counter = 0;
    joh_bonham->current_beat_index = -1;
    
    return available_rhythms[rhythm_index].name;
}

// processa sons
int16_t baqueta_tempo(baterista *joh_bonham)
{
    if (!joh_bonham || joh_bonham->is_paused) return 0;

    // calcula proxim som a ser tocado
    int8_t current_beat = (joh_bonham->time_counter*joh_bonham->current_bpm)/(joh_bonham->sampling_rate*15);
    //verifica se avançou para nova batida
    if (current_beat > joh_bonham->current_beat_index) {
        if (current_beat >= joh_bonham->pattern_length) {
            current_beat = 0;
            joh_bonham->time_counter = 0;
        }
        joh_bonham->current_beat_index = current_beat;
        uint8_t beat_events = joh_bonham->rhythm_pattern[current_beat];
        // processa sons
        if (beat_events & KICK_BIT) {
            joh_bonham->sound_position = 0;
            joh_bonham->active_sound_data = KICK;
            joh_bonham->sound_length = sizeof(KICK) / sizeof(KICK[0]);
        }
        else if (beat_events & CLAP_BIT) {
            joh_bonham->sound_position = 0;
            joh_bonham->active_sound_data = CLAP;
            joh_bonham->sound_length = sizeof(CLAP) / sizeof(CLAP[0]);
        }
        else if (beat_events & CRASH_BIT) {
            joh_bonham->sound_position = 0;
            joh_bonham->active_sound_data = CRASH;
            joh_bonham->sound_length = sizeof(CRASH) / sizeof(CRASH[0]);
        }
    }
    int16_t audio_sample = 0;
    if (joh_bonham->active_sound_data != 0) {
        audio_sample = joh_bonham->active_sound_data[joh_bonham->sound_position];
        joh_bonham->sound_position++;
        if (joh_bonham->sound_position >= joh_bonham->sound_length) {
            joh_bonham->active_sound_data = 0;
        }
    }
    joh_bonham->time_counter++;

    return audio_sample;
}


//pause e play (PB0)
void pause_play(baterista *joh_bonham)
{
    if (!joh_bonham) return;
    joh_bonham->is_paused = !joh_bonham->is_paused;
}

//nome do ritmo
const char *get_rhythm_name(baterista *joh_bonham)
{
    if (!joh_bonham) return " ";
    
    for (int i = 0; i < sizeof(available_rhythms) / sizeof(available_rhythms[0]); i++) {
        if (joh_bonham->rhythm_pattern == available_rhythms[i].pattern) {
            return available_rhythms[i].name;
        }
    }
    return " ";
}

//define bbpm
void setbpm(baterista *joh_bonham, uint8_t new_bpm)
{
    if (!joh_bonham) return;
    joh_bonham->time_counter = (joh_bonham->time_counter * joh_bonham->current_bpm) / new_bpm;
    joh_bonham->current_bpm = new_bpm;
}