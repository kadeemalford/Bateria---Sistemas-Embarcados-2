
#include <stdint.h>
#include "clock_efm32gg_ext.h"
#include "em_device.h"
#include "pwm.h"
#include "touch.h"
#include "button.h"
#include "lcd.h"
#include "bateria.h"

// PINO PC0 = saida do PWM  
#define AUDIO_PWM_CHANNEL     1
#define PWM_TIMER_LOCATION    PWM_LOC4
#define PWM_TIMER             TIMER0
#define TOUCH_SCAN_INTERVAL   200

// amostragem e bpm inical
const uint32_t SystemSampleRate = 44100;
baterista *new_batera;
char bpm_display[4] = "000";

// atualiza display do ritmo tocado
void update_rhythm_display(const char *rhythm_name)
{
    LCD_WriteAlphanumericDisplay(rhythm_name);
}

// troca bpm
void change_bpm_setting(baterista *joh_bonham, uint8_t new_bpm)
{
    setbpm(joh_bonham, new_bpm);
}

// button callback
void handle_button_event(uint32_t button_state)
{
    uint32_t released_buttons = Button_ReadReleased();
    // play/pause
    if (released_buttons & BUTTON1)
    {
        pause_play(new_batera);
    }
    //  troca ritmo
    if (released_buttons & BUTTON2)
    {
        const char *next_rhythm = get_next_rhythm(new_batera);
        update_rhythm_display(next_rhythm);
    }
}

void SysTick_Handler(void)
{
    static int touch_timer = 0;
    
    if (touch_timer > 0) {
        touch_timer--;
    } else {
        touch_timer = TOUCH_SCAN_INTERVAL;
        Touch_PeriodicProcess();
        
        uint32_t touch_data = Touch_Read();
        int touch_position = Touch_GetCenterOfTouch(touch_data);
        
        if (touch_position > 0) {
            uint8_t calculated_bpm = 50+(7-touch_position)*20;  
            change_bpm_setting(new_batera, calculated_bpm);
        }
    }
    int16_t audio_sample = baqueta_tempo(new_batera);
    uint32_t pwm_value = (uint32_t)(audio_sample + 32768) >> 8;
    PWM_Write(PWM_TIMER, 1, pwm_value);
}


int main(void)
{
    (void)SystemCoreClockSet(CLOCK_HFXO, 1, 1);
    Button_Init(BUTTON1 | BUTTON2);
    Button_SetCallback(handle_button_event);
    LCD_Init();
    PWM_Init(PWM_TIMER, PWM_TIMER_LOCATION, PWM_PARAMS_CH1_ENABLEPIN);
    Touch_Init();

    // bateria config
    bateria_config specs = {
        .sample_rate = SystemSampleRate,
        .bpm = 80,
        .beats_per_bar = 4
    };
    
    new_batera = bateria_instance();
    bateria_on(new_batera, specs);
    update_rhythm_display(get_rhythm_name(new_batera));

    __enable_irq();
    SysTick_Config(SystemCoreClock / SystemSampleRate);

    while (1)
    {
        __WFI();
    }
}