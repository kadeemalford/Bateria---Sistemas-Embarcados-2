#ifndef AUDIO_PLAYER_H
#define AUDIO_PLAYER_H

#include <stdint.h>

typedef struct bateria baterista;

// struct das configs de criacao ritmo
typedef struct {
    uint32_t sample_rate;      
    uint8_t  bpm;              
    uint8_t  beats_per_bar;   
} bateria_config;

baterista *bateria_instance(void);

void bateria_on(baterista *joh_bonham, bateria_config config);

int16_t baqueta_tempo(baterista *joh_bonham);

void pause_play(baterista *joh_bonham);

const char *get_next_rhythm(baterista *joh_bonham);

const char *get_rhythm_name(baterista *joh_bonham);

void setbpm(baterista *joh_bonham, uint8_t bpm);

#endif 